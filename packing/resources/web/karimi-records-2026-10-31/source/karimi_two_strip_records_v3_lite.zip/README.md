# Two-strip square packings: improved upper bounds for s(n), version 3

**Author:** Mohsen Karimi (Independent researcher, Zanjan, Iran), ORCID 0009-0004-1055-8267

This record set holds **5308** packings of n unit squares in a square of side
s < ⌈√n⌉, for n between 1182 and 9944 (boxes K = ⌈√n⌉ = 35 to 100). Each one improves
the best side listed for its n in the catalogues Mishapolk/square-packing-records
(commit 7e82c64, 23 Oct 2026) and franciscouzo/square-packing (commit 1c17153,
24 Oct 2026), comparing with their verified entries.

* Version 2 (2824 records) searched sides in [K − 0.1, K).
* Version 3 adds the search in [K − 0.5, K − 0.1): **2484 new values of n**, and
  smaller sides for 1434 of the version 2 records.
* Improvements over the previous best side: from 0.00016 up to 0.204.

## Construction

The two-strip construction was found by Mohsen Karimi, independently of S. Ryu's
L-shaped packing (doi:10.5281/zenodo.23278927, Theorem 1.3), of which it is an
instance with independent widths, angles and phases for the two bands.
In a box of side S just below an integer K:

* **H strip:** mH rows of squares tilted by a small angle, on the bottom wall, from
  the left wall to the V strip;
* **V strip:** mV columns, the same construction turned by 90°, on the right wall, full
  height;
* **Grid:** (K − mV) × (K − mH) axis-parallel squares in the top-left corner.

Angles have rational t = tan(a/2), so all coordinates are exact rationals.

## Files

* `records.csv` — one row per n: exact and decimal new side, previous best side
  (verified catalogue entry), construction parameters (K, mH, tH, phH, mV, tV, phV),
  and `below_all_reported`: `yes` if the side is also below every other side listed in
  the two catalogues, including sides derived from Kaggle leaderboard values without
  coordinates; `no` for the 51 rows where such a side is smaller.
* `regenerate.py` — rebuilds every certificate exactly from `records.csv`
  (Python standard library only, about three minutes for all rows):

      python3 regenerate.py            # all rows -> certificates/n<N>.cert
      python3 regenerate.py 2458 6250  # selected n

## Verification

Every certificate (format `x y t` per square, t = tan(θ/2), exact rationals) was
checked with the exact rational verifier `verify_bound_certificate.py`
(Mishapolk/square-packing-records, commit 7e82c64; MIT, E. Daniel, modifications by
F. Couzo): closed container, disjoint interiors, all 5308 accepted.
Search and verification code: `karimi_two_strip_code_v1_lite.zip` in this record.

## Credits

Construction idea, strip cost–benefit analysis and research direction: Mohsen Karimi.
Code and computations were done with the assistance of Claude (Anthropic) under the
author's direction; part of the search was run by the author in MATLAB Online.

License: data CC BY 4.0; code MIT.
