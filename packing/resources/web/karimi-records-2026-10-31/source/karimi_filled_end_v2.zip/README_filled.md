# Filled-end two-band L packings, n = 1184–9946 (version 1)

Mohsen Karimi (ORCID 0009-0004-1055-8267), Independent Researcher, Zanjan, Iran.

## Contents
- `filled_records.csv` — one row per n: K, exact side (`side_exact`), decimal side, previous best side and its source, and the construction parameters (bV, tV, yV, bH, tH, yH; all exact rationals).
- `filled_ends.py` — exact construction (fractions only).
- `regenerate_filled.py` — rebuilds `certificates_filled/n<N>.cert` from each row (`python3 regenerate_filled.py` or `python3 regenerate_filled.py 9946`).
- `check_cert.py` — a small independent exact checker (`python3 check_cert.py file.cert --mutate`).

Certificate format: `n S` header, then one line `x y t` per unit square (centre, t = tan(θ/2)), the format of Mishapolk/square-packing-records.

## Construction and credit
- L-shaped frame (aligned grid plus two tilted bands): Sungjoon Ryu, doi:10.5281/zenodo.23278927, Theorem 1.3.
- Band ends filled with axis-parallel layers: Evan Daniel (evand/square-packing, certificates/k2-minus-c/, 18 October 2026); band and fill as written in Kevin Fang's note, doi:10.5281/zenodo.23624565, Sections 2–3.
- Independent width b, tilt t = tan(θ/2) and lift split of each band, and the per-n search: Mohsen Karimi.
- Code and computations were done with the assistance of Claude (Anthropic) under the author's direction; the search was run in MATLAB Online and reproduced in Python.

## Rows
- 4261 rows improve the author's earlier records (Zenodo 10.5281/zenodo.23664800, v5).
- 310 rows are values of n not in v5 whose side is below the entry of Mishapolk/square-packing-records at ab8e833.
- Not compared: Couzo's index or other registers.

## Verification
Every certificate is rebuilt in exact rational arithmetic from its row and accepted by verify_bound_certificate.py of Mishapolk/square-packing-records (ab8e833).
