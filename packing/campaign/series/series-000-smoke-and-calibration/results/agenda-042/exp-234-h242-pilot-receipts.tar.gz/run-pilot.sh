#!/bin/bash
# Session 158, H-242 pilot. Pause-tolerant: node caps only (no wall caps), each box skipped
# if its summary exists, so a laptop sleep or a restart only delays. Narrowest widths first.
W=/Users/levy/wrk/github/squares/.claude/worktrees/w3-review
P=$W/attic/rung1-pilot/run
LOG=$W/attic/rung1-pilot/pilot.log
mkdir -p $P
cd $W/packing
echo "$(date -u +%FT%TZ) pilot start producer=$(git hash-object cases/trump11/fixed_angle_tree.py) reader=$(git hash-object cases/trump11/fixed_angle_tree_check.py)" >> $LOG
for w in w4 w3 w2; do
  grep -- "-$w\.json$" $W/attic/rung1-pilot/commands.txt | while read -r line; do
    name=$(echo "$line" | sed -E 's/.*--summary \$P\/([a-z0-9-]+)\.json.*/\1/')
    [ -f "$P/$name.json" ] && { echo "$(date -u +%FT%TZ) skip $name (done)" >> $LOG; continue; }
    tlo=$(echo "$line" | sed -E 's/.*--t-lo ([0-9.]+).*/\1/'); thi=$(echo "$line" | sed -E 's/.*--t-hi ([0-9.]+).*/\1/')
    echo "$(date -u +%FT%TZ) start $name t=[$tlo,$thi]" >> $LOG
    rm -rf "$P/$name.jsonl.gz" "$P/$name.sub" "$P/$name.json.part"
    .venv/bin/python3 -m cases.trump11.fixed_angle_tree box --t-lo $tlo --t-hi $thi --strong 6 --node-cap 150000 --wall-cap 1000000000 --workers 9 \
      --out $P/$name.jsonl.gz --summary $P/$name.json.part > $P/$name.log 2>&1 && mv $P/$name.json.part $P/$name.json
    echo "$(date -u +%FT%TZ) producer $name exit $?" >> $LOG
    .venv/bin/python3 -m cases.trump11.fixed_angle_tree_check $P/$name.jsonl.gz --workers 9 --out $P/$name.reader.json > $P/$name.reader.log 2>&1
    echo "$(date -u +%FT%TZ) reader $name exit $? $(grep -o '"verdict": "[a-z]*"' $P/$name.reader.json 2>/dev/null)" >> $LOG
  done
done
echo "$(date -u +%FT%TZ) pilot done" >> $LOG
