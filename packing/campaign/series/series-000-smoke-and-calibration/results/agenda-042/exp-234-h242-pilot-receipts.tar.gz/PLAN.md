# Rung-1 Pilot Plan (H-112), Not Yet Run

Prices rung 1 of X-046 with the `box` preset of
`packing/cases/trump11/fixed_angle_tree.py`: the same six-plus-five family, cores, rows,
certificates and reader as H-236, on a declared half-tangent box at target U's rational
upper end. Nothing below has been run beyond the smoke measurements in the last section.

## What It Measures

For each box: does the tree close, stop at an open leaf (`stopped-on-open`, meaning the
box is too wide for its core or the family really goes below U there), or hit its cap;
and at what nodes per second, closed measure and largest expanded LP value.
Rung 1 must cover `t` in `[0.016115, 0.412923]` (the strips `theta <= 1.8465 deg` and
`theta >= 45 deg - 0.1263 deg` are closed by X-046's transfer corollaries) apart from
the box around `t* = 0.365769...`, which uses the Trump image. That is about 40 boxes at
width `1e-2`, 400 at `1e-3` and 4,000 at `1e-4`.

## Boxes

Six centres, `c = tan(theta/2)` rounded to four decimals, at
`theta = 6, 13, 20, 27, 33, 43.5` degrees, all away from `theta* = 40.18` degrees; each
at half-tangent widths `1e-2`, `1e-3`, `1e-4` centred on `c`. All 18 were dry-run at
node cap 1: every header has target label `U` and no image.

## Commands

From `packing/`, at most two at once (`xargs -P 2`), widest first per centre. Caps per
box: 750,000 nodes or 900 s of wall, whichever first; the whole stage is at most about
2.3 hours on two cores.

```bash
cd packing
export P=../attic/rung1-pilot
xargs -P 2 -I{} sh -c '{}' < $P/commands.txt
```

`commands.txt` holds these 18 lines verbatim:

```bash
.venv/bin/python3 -m cases.trump11.fixed_angle_tree box --t-lo 0.0474 --t-hi 0.0574 --strong 6 --node-cap 750000 --wall-cap 900 --out $P/th06-w2.jsonl.gz --summary $P/th06-w2.json
.venv/bin/python3 -m cases.trump11.fixed_angle_tree box --t-lo 0.0519 --t-hi 0.0529 --strong 6 --node-cap 750000 --wall-cap 900 --out $P/th06-w3.jsonl.gz --summary $P/th06-w3.json
.venv/bin/python3 -m cases.trump11.fixed_angle_tree box --t-lo 0.05235 --t-hi 0.05245 --strong 6 --node-cap 750000 --wall-cap 900 --out $P/th06-w4.jsonl.gz --summary $P/th06-w4.json
.venv/bin/python3 -m cases.trump11.fixed_angle_tree box --t-lo 0.1089 --t-hi 0.1189 --strong 6 --node-cap 750000 --wall-cap 900 --out $P/th13-w2.jsonl.gz --summary $P/th13-w2.json
.venv/bin/python3 -m cases.trump11.fixed_angle_tree box --t-lo 0.1134 --t-hi 0.1144 --strong 6 --node-cap 750000 --wall-cap 900 --out $P/th13-w3.jsonl.gz --summary $P/th13-w3.json
.venv/bin/python3 -m cases.trump11.fixed_angle_tree box --t-lo 0.11385 --t-hi 0.11395 --strong 6 --node-cap 750000 --wall-cap 900 --out $P/th13-w4.jsonl.gz --summary $P/th13-w4.json
.venv/bin/python3 -m cases.trump11.fixed_angle_tree box --t-lo 0.1713 --t-hi 0.1813 --strong 6 --node-cap 750000 --wall-cap 900 --out $P/th20-w2.jsonl.gz --summary $P/th20-w2.json
.venv/bin/python3 -m cases.trump11.fixed_angle_tree box --t-lo 0.1758 --t-hi 0.1768 --strong 6 --node-cap 750000 --wall-cap 900 --out $P/th20-w3.jsonl.gz --summary $P/th20-w3.json
.venv/bin/python3 -m cases.trump11.fixed_angle_tree box --t-lo 0.17625 --t-hi 0.17635 --strong 6 --node-cap 750000 --wall-cap 900 --out $P/th20-w4.jsonl.gz --summary $P/th20-w4.json
.venv/bin/python3 -m cases.trump11.fixed_angle_tree box --t-lo 0.2351 --t-hi 0.2451 --strong 6 --node-cap 750000 --wall-cap 900 --out $P/th27-w2.jsonl.gz --summary $P/th27-w2.json
.venv/bin/python3 -m cases.trump11.fixed_angle_tree box --t-lo 0.2396 --t-hi 0.2406 --strong 6 --node-cap 750000 --wall-cap 900 --out $P/th27-w3.jsonl.gz --summary $P/th27-w3.json
.venv/bin/python3 -m cases.trump11.fixed_angle_tree box --t-lo 0.24005 --t-hi 0.24015 --strong 6 --node-cap 750000 --wall-cap 900 --out $P/th27-w4.jsonl.gz --summary $P/th27-w4.json
.venv/bin/python3 -m cases.trump11.fixed_angle_tree box --t-lo 0.2912 --t-hi 0.3012 --strong 6 --node-cap 750000 --wall-cap 900 --out $P/th33-w2.jsonl.gz --summary $P/th33-w2.json
.venv/bin/python3 -m cases.trump11.fixed_angle_tree box --t-lo 0.2957 --t-hi 0.2967 --strong 6 --node-cap 750000 --wall-cap 900 --out $P/th33-w3.jsonl.gz --summary $P/th33-w3.json
.venv/bin/python3 -m cases.trump11.fixed_angle_tree box --t-lo 0.29615 --t-hi 0.29625 --strong 6 --node-cap 750000 --wall-cap 900 --out $P/th33-w4.jsonl.gz --summary $P/th33-w4.json
.venv/bin/python3 -m cases.trump11.fixed_angle_tree box --t-lo 0.394 --t-hi 0.404 --strong 6 --node-cap 750000 --wall-cap 900 --out $P/th43p5-w2.jsonl.gz --summary $P/th43p5-w2.json
.venv/bin/python3 -m cases.trump11.fixed_angle_tree box --t-lo 0.3985 --t-hi 0.3995 --strong 6 --node-cap 750000 --wall-cap 900 --out $P/th43p5-w3.jsonl.gz --summary $P/th43p5-w3.json
.venv/bin/python3 -m cases.trump11.fixed_angle_tree box --t-lo 0.39895 --t-hi 0.39905 --strong 6 --node-cap 750000 --wall-cap 900 --out $P/th43p5-w4.jsonl.gz --summary $P/th43p5-w4.json
```

Then the reader on every tree that ends `complete` or `stopped-on-open`:

```bash
.venv/bin/python3 -m cases.trump11.fixed_angle_tree_check $P/<name>.jsonl.gz --out $P/<name>-reader.json
```

## What to Record per Box

`stopped` (`complete`, `stopped-on-open`, `node-cap`, `wall-cap`), `nodes_solved`,
`nodes_per_second`, `closed_measure`, `max_lp_value_expanded`, and for an open leaf its
LP value and point from `unresolved_sample`; the reader's verdict and
`smallest_certified_margin` where run.
A reader-closed box is a verified exact statement for that box only (every packing of
the family in it has side above U's upper end).
A `stopped-on-open` box is a reader-checkable non-closure at that width, not evidence
against H-112.
A capped box prices nothing on its own; `closed_measure` weights each option equally and
is not an extrapolator.

## Smoke Already Measured (Not the Pilot)

At `theta = 20 deg`, target U, `--strong 6`, one process: width `1e-4`
(`[0.1763, 0.1764]`) ran 30,000 nodes in 32.4 s (926 nodes/s, 145,152 LP solves),
closed measure 0.0166, largest expanded LP value 3.876871 (U = 3.877084), no open leaf.
Widths `1e-2` and `1e-3` at the same centre, run two at a time beside the edit tier,
gave 456 and 488 nodes/s, closed measure 0.0042 and 0.0166, largest expanded LP values
3.876961 and 3.876990, no open leaf.
Knuth estimates with 300 probes (`--probes 300`) are not usable for pricing: three seeds
at the far box gave `log10` means 4.9 to 6.6, and the same estimator on `h236` gave 5.6
and 6.1 against the actual 1.7e8 nodes, with 68 to 99 percent of each mean from the top
1 percent of dives.
